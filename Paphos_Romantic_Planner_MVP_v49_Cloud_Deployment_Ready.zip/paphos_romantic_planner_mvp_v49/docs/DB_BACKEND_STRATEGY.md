# Database backend strategy

## Development validation
SQLite is used only to prove that the application can seed a relational database and generate itineraries using SQL-backed repositories.

## Production target
PostgreSQL remains the target defined by migrations `001`–`015`.

The application layer should keep repository interfaces stable so SQLite can be replaced by PostgreSQL without changing scoring and itinerary-composition rules.

## Non-negotiable invariants
- Preserve `PFO-H*`, `PFO-A*`, and `PFO-R*` identifiers.
- C13 is Pissouri / Limassol cross-district, never Paphos.
- Draft/Inactive records cannot be auto-primary.
- Needs Recheck records require confirmation/conditional treatment.
- Provider fallback/stale data cannot be labelled LIVE.
