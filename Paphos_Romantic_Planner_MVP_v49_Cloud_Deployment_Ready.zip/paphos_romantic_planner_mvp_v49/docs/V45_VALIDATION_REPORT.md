# v45 Validation Report

Date: 2026-08-27

## Runtime architecture
- Database-backed runtime: SQLite dev DB
- Production target: PostgreSQL migrations retained
- Curated data: 13 clusters / 32 hotels / 166 activities / 27 dining records
- Mappings: 3,017 hotel→activity / 507 hotel→restaurant
- Routing provider: NOT_CONNECTED
- Weather provider: NOT_CONNECTED

## New operational validation
- Opening-day/date evaluation
- Opening-window fitting
- Day-1 arrival/check-in/lunch/rest protection
- Booking reminders
- Heatwave/rain/winter eligibility
- Rain-safe candidate preference
- Planning travel minutes
- Dinner service-window validation
- Operational status per stop and day
- Explicit trip validation endpoint

## Automated validation
- Python compile: PASS
- Pytest: 26/26 PASS
- FastAPI generate endpoint: HTTP 200
- FastAPI validate endpoint: HTTP 200

## Verified scenario examples
### Aphrodite Hills / Active / Normal
Day 1: Aphrodite Hills Riding Club, 16:30–17:30, booking required, operational PASS.

### Elysium / Rainy
The fresh runtime avoids Pafos Medieval Castle as the Day-2 primary and prefers a rain-safe indoor/authentic option.

## Important limitations
- Opening-day strings that cannot be safely interpreted are RECHECK, never assumed open.
- Seasonal/event/booking-dependent departure times remain RECHECK where appropriate.
- Travel times are planning bands, not live driving times.
- Auto weather falls back to Normal planning mode while the weather provider is disconnected.
- No route or weather fallback is labelled LIVE.
