# Implementation status

## Implemented in this scaffold
- Curated seed extraction
- FastAPI health endpoint
- FastAPI itinerary generation endpoint
- Deterministic scoring prototype
- Strict primary-activity no-repeat
- C13/Pissouri cluster eligibility guard
- Horse-riding active-interest bonus
- PostgreSQL DDL/migrations
- Seed importer and QA
- Unit/regression tests
- Provider stubs with live services disabled by default

## Still required for production
- Execute migrations on dev/staging DB
- Replace CSV runtime store with PostgreSQL repositories
- Full operational-day/opening-time parser
- Actual route-leg construction for every itinerary stop
- Route/weather caching, retries and circuit breakers
- Real provider credentials in server-side secret store
- Content-admin UI/workflow
- Customer UI
- Auth/tenant/billing implementation
- Observability deployment
- Real route/weather acceptance tests
