# API examples

## Health
`GET /api/v1/health`

Expected before live-provider connection:
```json
{
  "service": "ok",
  "routing_provider": "not_connected",
  "weather_provider": "not_connected"
}
```

## Generate itinerary
`POST /api/v1/trips/generate`

The current MVP generator uses the real curated seed dataset and planning mappings.  
Its provider state is intentionally `NOT_CONNECTED`, and returned trips are `FALLBACK_READY`.
