# v46 Route-Aware Daily Timeline Validation

Date: 2026-08-27

## New runtime behavior
- Every generated day now includes an ordered timeline.
- Planning travel buffers are inserted before activities/meals and on hotel return.
- Arrival day retains check-in, lunch and rest protection.
- Full days may add one secondary activity only when it fits operationally.
- Secondary activities must be <=90 minutes, add category variety and respect hotel/activity geography.
- Hidden gaps are represented as lunch/free-time/rest/coffee blocks.
- Timeline QA calculates overlap count, travel minutes, external stop count and load classification.
- Overlap => BLOCKED; non-live travel remains PLANNING/RECHECK, never LIVE.

## Validation
- Python compile: PASS
- Automated tests: 33/33 PASS
- Generate API: HTTP 200
- Validate API: HTTP 200
- Reference timeline overlap count: 0

## Important limitation
Inter-stop travel is still a conservative planning buffer derived from hotel mapping bands, not a real route between the two selected stops. Google Routes remains NOT_CONNECTED. The next live-routing layer must replace these planning buffers with actual leg durations before any LIVE route label.
