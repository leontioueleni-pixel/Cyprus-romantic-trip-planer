# v44 validation report

Date: 2026-08-27

## Database runtime
- Backend used for executable local validation: SQLite
- Production target retained: PostgreSQL
- Seed counts: 13 clusters, 32 hotels, 166 activities, 27 restaurants/cafes, 3,017 hotel-activity mappings, 507 hotel-restaurant mappings.
- Runtime generator reads through `app.repository`, backed by SQL queries.

## Automated tests
- 13 passed
- Covers rules, C13/Pissouri, seed parity, foreign-key integrity, mapping integrity, active horse-riding scenarios, no-repeat, and generator output.

## API smoke test
- `GET /api/v1/health`: HTTP 200
- `POST /api/v1/trips/generate`: HTTP 200
- Test case: Aphrodite Hills Hotel, active profile, 3 nights.
- Day 1 selected: Aphrodite Hills Riding Club – Guided Countryside Trail.
- Route provider: NOT_CONNECTED
- Weather provider: NOT_CONNECTED
- Trip status: FALLBACK_READY

## Truthfulness
No simulated or fallback provider value is represented as LIVE.

## Still required
1. Run PostgreSQL migrations on a real dev/staging Postgres instance.
2. Replace the SQLite adapter with PostgreSQL repository implementation for deployment.
3. Add operational hours/date validation from the richer master fields.
4. Build actual route legs and weather coordinate requests per generated itinerary.
5. Connect server-side provider credentials.
6. Run real live acceptance tests before enabling LIVE badges.
