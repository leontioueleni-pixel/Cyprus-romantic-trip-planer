# Cyprus Romantic Trip Planner – Paphos MVP Backend

First runnable software scaffold derived from the curated Paphos master workbooks.

## What is real in this repository

- Seed data exported from the project master:
  - 13 clusters
  - 32 qualified hotel bases
  - 166 activities
  - 27 restaurants/cafes
  - 3,017 hotel→activity mappings
  - 507 hotel→restaurant mappings
- FastAPI trip-generation endpoint
- PostgreSQL migrations M01–M15
- Seed importer and seed QA
- Regression tests for Pissouri C13, horse riding, no-repeat, seed parity
- Provider adapters that default to `NOT_CONNECTED`

## What is NOT live

Google Routes and weather calls are disabled by default. No API key is bundled.  
Fallback output must never be described as LIVE.

## Quick start

```bash
cp .env.example .env
docker compose up -d db
pip install -r requirements.txt

# Apply migrations
for f in migrations/*.sql; do psql "$DATABASE_URL" -f "$f"; done

# Import curated seed data
python scripts/import_seed.py
python scripts/qa_seed.py

# Run tests
pytest -q

# Start API
uvicorn app.main:app --reload
```

Then open `/docs` for the FastAPI Swagger UI.

## Example request

```json
{
  "hotel_id": "PFO-H010",
  "start_date": "2026-09-10",
  "nights": 3,
  "arrival_time_local": "11:00",
  "transport": "rental_car",
  "max_drive_min": 20,
  "pace": "active",
  "authentic_priority": true,
  "interest_sea": true,
  "interest_wine_food": true,
  "interest_nature": true,
  "interest_culture": true,
  "interest_active": true,
  "weather_mode": "auto",
  "locale": "el-CY"
}
```

POST to:

`/api/v1/trips/generate`

## Important architecture rule

Pissouri is cluster `C13`, administratively **Limassol**, and is only eligible as a normal cross-district extension from `C02` (Kouklia / Aphrodite Hills corridor). A future live-routing validation must still check the user's actual max-drive preference.

## Next engineering work

1. Run migrations against a real dev PostgreSQL instance.
2. Seed the database and run `qa_seed.py`.
3. Replace CSV seed-store reads in the generator with repository/database queries.
4. Implement date/opening-hours validation from the richer master fields.
5. Connect server-side Google Routes and weather adapters.
6. Run real live acceptance before any `LIVE` badge is shown.

## v44 database-backed dev validation

This version adds a real SQLite development database so the runtime generator no longer reads CSV files directly.
The PostgreSQL migrations remain the production target; SQLite is only the executable local/dev validation layer available in this environment.

Validated in v44:
- SQLite dev DB created and seeded from the curated master exports.
- Runtime repository reads hotels, activities, dining and mappings from SQL queries.
- 13 automated tests pass.
- FastAPI `/api/v1/health` returns HTTP 200.
- FastAPI `/api/v1/trips/generate` returns HTTP 200 using DB-backed data.
- Aphrodite Hills active scenario selects the local Riding Club as expected.
- Provider status remains `NOT_CONNECTED`; trip status remains `FALLBACK_READY` until real route/weather services are connected.

To recreate the local database:

```bash
python scripts/init_sqlite.py
pytest -q
uvicorn app.main:app --reload
```


# v45 Operational Validation Engine

The runtime now evaluates operational suitability before selecting the primary activity:

- selected calendar date / weekday
- known opening-day text
- parsed or explicit opening windows
- activity duration fit inside the operating window
- booking-required reminders
- rain / heatwave / winter suitability
- established heatwave rule for long outdoor activities
- planning travel minutes from mapping bands
- Day-1 arrival/check-in/lunch/rest blocks
- dinner service windows where safely parsable
- explicit `PASS / RECHECK / CLOSED / TIME_FAIL / WEATHER_FAIL`
- `/api/v1/trips/validate` endpoint

Provider truth remains unchanged: routing and weather are `NOT_CONNECTED` until real backend providers return valid fresh responses.


# v46 Route-Aware Daily Timeline

Each day now returns an explicit `timeline` and `timeline_qa`.

The timeline contains:
- hotel/free-time blocks
- planning travel buffers
- primary activity
- optional second activity on full days
- coffee/rest gaps where useful
- dinner
- return to hotel

`timeline_qa` exposes:
- overlap count
- planned commitment minutes
- total planning travel minutes
- external stop count
- LIGHT/BALANCED/BUSY/OVERLOADED classification
- PASS/RECHECK/BLOCKED

Travel durations are still planning estimates from the curated mapping layer. They are not live Google Routes results and are always clearly treated as planning data.


# v47 Browser Web Interface

The MVP now has a simple browser user interface at:

`http://127.0.0.1:8000/`

For Windows, the easiest route is to double-click `START_WINDOWS.bat`.

The UI includes hotel selection, trip dates, nights, arrival time, max drive, budget, pace,
weather mode and tourism interests. It calls both `/api/v1/trips/generate` and
`/api/v1/trips/validate` and renders the operational timeline in a human-readable format.
Swagger remains available at `/docs`.


# v48 Mobile-Ready / Android LAN Access

For Android testing on the same Wi-Fi as the Windows PC:

1. Double-click `START_MOBILE_WINDOWS.bat`.
2. Keep the command window open.
3. Open Chrome on Android.
4. Enter the displayed LAN URL, e.g. `http://192.168.1.25:8000`.

The app now binds to `0.0.0.0` in the mobile launcher and exposes `/api/v1/meta/network`.
The web interface includes additional responsive rules for smaller Android screens.


# v49 Cloud Deployment Ready

This version adds public-cloud deployment files:

- `Dockerfile`
- `render.yaml`
- `railway.json`
- `Procfile`
- `scripts/start_cloud.sh`
- `DEPLOY_RENDER.md`
- `DEPLOY_RAILWAY.md`
- `CLOUD_QUICK_START.txt`

The recommended first public test is Render. Once deployed, set `PUBLIC_BASE_URL` to the assigned HTTPS domain.
Android can then access the planner through mobile data or any network.

The current MVP rebuilds its curated read-mostly SQLite database from seed files on container start.
Before persisted customer accounts/trips/payments are implemented, the transactional database must move to PostgreSQL.
