import os, psycopg
DB=os.environ["DATABASE_URL"]
checks=[
("clusters", "select count(*) from cluster", 13),
("hotels", "select count(*) from hotel", 32),
("activities", "select count(*) from activity", 166),
("restaurants", "select count(*) from restaurant", 27),
("hotel_activity_mapping", "select count(*) from hotel_activity_mapping", 3017),
("hotel_restaurant_mapping", "select count(*) from hotel_restaurant_mapping", 507),
]
with psycopg.connect(DB) as conn:
    with conn.cursor() as cur:
        for name,sql,expected in checks:
            cur.execute(sql); got=cur.fetchone()[0]
            assert got==expected, f"{name}: expected {expected}, got {got}"
        cur.execute("select district,cross_district from cluster where cluster_id='C13'")
        assert cur.fetchone()==("Limassol",True)
print("seed QA PASS")
