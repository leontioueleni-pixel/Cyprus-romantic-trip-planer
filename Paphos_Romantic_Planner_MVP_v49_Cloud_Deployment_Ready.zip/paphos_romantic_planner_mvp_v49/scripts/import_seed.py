from __future__ import annotations
import csv, json, os
from pathlib import Path
import psycopg

ROOT=Path(__file__).resolve().parents[1]
SEED=ROOT/"seed"
CONTENT_VERSION=os.getenv("CONTENT_VERSION","content_2026_08_27")
DB=os.environ["DATABASE_URL"]

def rows(name):
    with (SEED/name).open(encoding="utf-8",newline="") as f:
        yield from csv.DictReader(f)

def num(v):
    return None if v in ("",None) else float(v)

with psycopg.connect(DB) as conn:
    with conn.cursor() as cur:
        cur.execute("INSERT INTO content_release(content_version,notes) VALUES (%s,%s) ON CONFLICT DO NOTHING",
                    (CONTENT_VERSION,"Seed imported from v37 master"))
        for r in rows("clusters.csv"):
            cur.execute("""INSERT INTO cluster(cluster_id,name,district,cross_district,content_version,main_areas,profile,notes)
                VALUES (%s,%s,%s,%s,%s,%s,%s,%s)
                ON CONFLICT(cluster_id) DO UPDATE SET name=EXCLUDED.name,district=EXCLUDED.district,
                cross_district=EXCLUDED.cross_district,content_version=EXCLUDED.content_version,
                main_areas=EXCLUDED.main_areas,profile=EXCLUDED.profile,notes=EXCLUDED.notes""",
                (r["cluster_id"],r["name"],r["district"],r["cross_district"]=="true",CONTENT_VERSION,r["main_areas"],r["profile"],r["notes"]))
        for r in rows("hotels.csv"):
            cur.execute("""INSERT INTO hotel(hotel_id,name,cluster_id,status,romantic_score,cleanliness_score,area,payload)
              VALUES (%s,%s,%s,%s,%s,%s,%s,%s::jsonb)
              ON CONFLICT(hotel_id) DO UPDATE SET name=EXCLUDED.name,cluster_id=EXCLUDED.cluster_id,status=EXCLUDED.status,
              romantic_score=EXCLUDED.romantic_score,cleanliness_score=EXCLUDED.cleanliness_score,area=EXCLUDED.area,payload=EXCLUDED.payload""",
              (r["hotel_id"],r["name"],r["cluster_id"],r["status"],num(r["romantic_score"]),num(r["cleanliness_score"]),r["area"],r["payload_json"]))
        for r in rows("activities.csv"):
            cur.execute("""INSERT INTO activity(activity_id,name,cluster_id,category,subcategory,data_status,romantic_score,authentic_score,duration_min,area,payload)
              VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s::jsonb)
              ON CONFLICT(activity_id) DO UPDATE SET name=EXCLUDED.name,cluster_id=EXCLUDED.cluster_id,category=EXCLUDED.category,
              subcategory=EXCLUDED.subcategory,data_status=EXCLUDED.data_status,romantic_score=EXCLUDED.romantic_score,
              authentic_score=EXCLUDED.authentic_score,duration_min=EXCLUDED.duration_min,area=EXCLUDED.area,payload=EXCLUDED.payload""",
              (r["activity_id"],r["name"],r["cluster_id"],r["category"],r["subcategory"],r["data_status"],
               num(r["romantic_score"]),num(r["authentic_score"]),None if not r["duration_min"] else int(float(r["duration_min"])),r["area"],r["payload_json"]))
        for r in rows("restaurants.csv"):
            cur.execute("""INSERT INTO restaurant(restaurant_id,name,cluster_id,data_status,area,meal_type,romantic_score,authentic_score,payload)
              VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s::jsonb)
              ON CONFLICT(restaurant_id) DO UPDATE SET name=EXCLUDED.name,cluster_id=EXCLUDED.cluster_id,data_status=EXCLUDED.data_status,
              area=EXCLUDED.area,meal_type=EXCLUDED.meal_type,romantic_score=EXCLUDED.romantic_score,authentic_score=EXCLUDED.authentic_score,payload=EXCLUDED.payload""",
              (r["restaurant_id"],r["name"],r["cluster_id"],r["data_status"],r["area"],r["meal_type"],num(r["romantic_score"]),num(r["authentic_score"]),r["payload_json"]))
        for r in rows("hotel_activity_mapping.csv"):
            cur.execute("""INSERT INTO hotel_activity_mapping(hotel_id,activity_id,content_version,travel_band,recommended_day1,weather_fit,romantic_score,data_status)
              VALUES (%s,%s,%s,%s,%s,%s,%s,%s) ON CONFLICT(hotel_id,activity_id,content_version) DO UPDATE SET
              travel_band=EXCLUDED.travel_band,recommended_day1=EXCLUDED.recommended_day1,weather_fit=EXCLUDED.weather_fit,
              romantic_score=EXCLUDED.romantic_score,data_status=EXCLUDED.data_status""",
              (r["Hotel_ID"],r["Activity_ID"],CONTENT_VERSION,r["Planning_Travel_Band"],r["Recommended_for_Day1"],r["Weather_Fit"],num(r["Romantic_Score"]),r["Data_Status"]))
        for r in rows("hotel_restaurant_mapping.csv"):
            cur.execute("""INSERT INTO hotel_restaurant_mapping(hotel_id,restaurant_id,content_version,travel_band,meal_type,romantic_score,data_status)
              VALUES (%s,%s,%s,%s,%s,%s,%s) ON CONFLICT(hotel_id,restaurant_id,content_version) DO UPDATE SET
              travel_band=EXCLUDED.travel_band,meal_type=EXCLUDED.meal_type,romantic_score=EXCLUDED.romantic_score,data_status=EXCLUDED.data_status""",
              (r["Hotel_ID"],r["Restaurant_ID"],CONTENT_VERSION,r["Planning_Travel_Band"],r["Meal_Type"],num(r["Romantic_Score"]),r["Data_Status"]))
    conn.commit()
print("seed import complete")
