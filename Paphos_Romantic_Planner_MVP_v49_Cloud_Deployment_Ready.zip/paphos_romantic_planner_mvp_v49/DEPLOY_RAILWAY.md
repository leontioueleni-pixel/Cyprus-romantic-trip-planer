# Deploy on Railway — alternative public test

This repository includes `railway.json` and `Dockerfile`.

## Steps
1. Create a GitHub repository containing this project.
2. In Railway create a new project and deploy from the GitHub repository.
3. Railway should detect/use the Dockerfile.
4. Add environment variables:
   - `APP_ENV=production`
   - `ENABLE_LIVE_PROVIDERS=false`
   - `CONTENT_VERSION=content_2026_08_27`
   - `RULES_VERSION=rules_1_0`
5. In Railway Networking, generate a public domain.
6. Copy that HTTPS URL and set:
   - `PUBLIC_BASE_URL=https://YOUR-RAILWAY-DOMAIN`
7. Redeploy.

Then open the generated HTTPS address from Android using mobile data.

## Health check
`https://YOUR-RAILWAY-DOMAIN/api/v1/health`

The app must continue to report route/weather providers as `not_connected` until real provider integrations pass live acceptance.
