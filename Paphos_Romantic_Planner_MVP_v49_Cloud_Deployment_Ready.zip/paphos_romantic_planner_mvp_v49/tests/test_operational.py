from datetime import date, time
from app.repository import activities, restaurants
from app.operational import schedule_activity, schedule_dinner, day_status
from app.schemas import TripRequest
from app.generator import generate

def test_known_activity_window_fits():
    a=activities()["PFO-A084"]  # 09:30–18:00
    op=schedule_activity(a,date(2026,9,10),2,time(11,0),"normal")
    assert op["eligible"]
    assert time(9,30) <= op["start"] <= time(18,0)
    assert op["end"] <= time(18,0)

def test_day1_protects_checkin_rest():
    a=activities()["PFO-A114"]  # spa 08:00–20:00
    op=schedule_activity(a,date(2026,9,10),1,time(11,0),"normal")
    assert op["eligible"]
    assert op["start"] >= time(16,30)

def test_booking_flag_horse_riding():
    a=activities()["PFO-A152"]
    op=schedule_activity(a,date(2026,9,10),1,time(11,0),"normal")  # Thursday
    assert op["eligible"]
    assert op["booking_required"] is True
    assert any("booking" in w.lower() for w in op["warnings"])

def test_horse_closed_day_is_not_eligible():
    a=activities()["PFO-A152"]
    op=schedule_activity(a,date(2026,9,9),1,time(11,0),"normal")  # Wednesday not listed
    # schedule is uncertain rather than silently OPEN, because source wording is by reservation/listed days
    assert op["status"] in {"RECHECK","CLOSED"}

def test_heatwave_blocks_inappropriate_activity_before_evening():
    a=activities()["PFO-A084"]  # Heatwave Suitable = No, best time morning/late afternoon
    op=schedule_activity(a,date(2026,9,10),2,time(11,0),"heatwave")
    assert op["eligible"] is False

def test_rain_blocks_outdoor_parasailing():
    a=activities()["PFO-A084"]
    op=schedule_activity(a,date(2026,9,10),2,time(11,0),"rainy")
    assert op["eligible"] is False

def test_known_dinner_window():
    r=restaurants()["PFO-R008"]
    op=schedule_dinner(r,date(2026,9,10))
    assert op["eligible"]
    assert op["start"] == time(20,0)
    assert op["end"] <= time(22,30)

def test_generated_itinerary_has_times_and_operational_status():
    req=TripRequest(hotel_id="PFO-H010",start_date=date(2026,9,10),nights=3,pace="active",interest_active=True,weather_mode="normal")
    out=generate(req)
    assert len(out.days)==4
    for d in out.days:
        assert d.activity.start_time is not None
        assert d.activity.end_time is not None
        assert d.operational_status in {"PASS","RECHECK"}


def test_day1_contains_arrival_lunch_rest_blocks():
    req=TripRequest(hotel_id="PFO-H001",start_date=date(2026,9,10),nights=3,weather_mode="normal")
    out=generate(req)
    blocks=out.days[0].fixed_blocks
    kinds=[b.kind for b in blocks]
    assert kinds==["arrival","checkin","meal","rest"]
    assert blocks[-1].end_time == time(16,0)

def test_rainy_generation_prefers_rain_safe_over_conditional_castle():
    req=TripRequest(hotel_id="PFO-H001",start_date=date(2026,9,10),nights=3,weather_mode="rainy")
    out=generate(req)
    assert out.days[1].activity.title != "Pafos Medieval Castle"


def test_ambiguous_until_dinner_hours_do_not_create_22_start():
    r=restaurants()["PFO-R022"]  # Symposio: "Until approx. 22:00–22:30"
    op=schedule_dinner(r,date(2026,9,13))
    assert op["eligible"]
    assert op["start"] <= time(20,0)
