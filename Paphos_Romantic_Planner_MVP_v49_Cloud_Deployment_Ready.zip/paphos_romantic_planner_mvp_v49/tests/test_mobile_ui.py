from fastapi.testclient import TestClient
from app.main import app

client=TestClient(app)

def test_network_meta_endpoint():
    r=client.get("/api/v1/meta/network")
    assert r.status_code==200
    data=r.json()
    assert "host_ip" in data
    assert data["mobile_url"].startswith("http://")
    assert data["mobile_url"].endswith(":8000")

def test_home_contains_mobile_hint():
    r=client.get("/")
    assert r.status_code==200
    assert "networkHint" in r.text
    assert "Generate Itinerary" in r.text
