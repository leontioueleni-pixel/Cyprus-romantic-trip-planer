from app.rules import proximity_score, status_score, c13_allowed

def test_proximity_scores():
    assert proximity_score("0–15 min")==20
    assert proximity_score("15–30 min")==15
    assert proximity_score("30–45 min")==8
    assert proximity_score("45+ min")==0

def test_status_scores():
    assert status_score("Verified")==10
    assert status_score("Needs Recheck")<0
    assert status_score("Draft")<status_score("Needs Recheck")

def test_pissouri_gate():
    assert c13_allowed("C02","C13")
    assert not c13_allowed("C01","C13")
    assert not c13_allowed("C05","C13")
