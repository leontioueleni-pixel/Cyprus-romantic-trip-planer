import os, sys, subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
TEST_DB=ROOT/'data'/'planner_test.sqlite3'
os.environ['SQLITE_DB_PATH']=str(TEST_DB)
subprocess.run([sys.executable,str(ROOT/'scripts'/'init_sqlite.py')],check=True,env=os.environ.copy(),stdout=subprocess.DEVNULL)
