from fastapi.testclient import TestClient
from app.main import app

client=TestClient(app)

def test_home_web_ui_loads():
    r=client.get("/")
    assert r.status_code==200
    assert "Generate Itinerary" in r.text
    assert "Cyprus Romantic Trip Planner" in r.text

def test_hotel_dropdown_data():
    r=client.get("/api/v1/meta/hotels")
    assert r.status_code==200
    data=r.json()
    assert len(data)==32
    assert any(h["name"]=="Aphrodite Hills Hotel" for h in data)

def test_ui_generate_contract():
    payload={
      "hotel_id":"PFO-H010","start_date":"2026-09-10","nights":3,
      "arrival_time_local":"11:00","transport":"rental_car","max_drive_min":20,
      "budget":"moderate","pace":"balanced","authentic_priority":True,
      "interest_sea":True,"interest_wine_food":True,"interest_nature":True,
      "interest_culture":True,"interest_wellness":False,"interest_active":False,
      "meal_preference":"cypriot_local","mobility":"no_limitation",
      "weather_mode":"normal","locale":"el-CY","currency":"EUR"
    }
    r=client.post("/api/v1/trips/generate",json=payload)
    assert r.status_code==200
    data=r.json()
    assert len(data["days"])==4
    assert "timeline" in data["days"][0]
