from fastapi.testclient import TestClient
from app.main import app

client=TestClient(app)

def test_validate_endpoint():
    r=client.post("/api/v1/trips/validate",json={
        "hotel_id":"PFO-H010",
        "start_date":"2026-09-10",
        "nights":3,
        "pace":"active",
        "interest_active":True,
        "weather_mode":"normal"
    })
    assert r.status_code==200
    data=r.json()
    assert data["status"] in {"PASS","RECHECK"}
    assert data["itinerary_status"]=="FALLBACK_READY"

def test_generate_exposes_times_and_travel_minutes():
    r=client.post("/api/v1/trips/generate",json={
        "hotel_id":"PFO-H010",
        "start_date":"2026-09-10",
        "nights":3,
        "pace":"active",
        "interest_active":True,
        "weather_mode":"normal"
    })
    assert r.status_code==200
    d=r.json()["days"][0]
    assert d["activity"]["start_time"] is not None
    assert d["activity"]["planning_travel_min"] is not None
    assert len(d["fixed_blocks"])==4
