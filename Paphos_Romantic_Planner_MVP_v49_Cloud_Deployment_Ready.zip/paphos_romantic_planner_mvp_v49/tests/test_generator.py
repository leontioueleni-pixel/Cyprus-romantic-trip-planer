from datetime import date
from app.schemas import TripRequest
from app.generator import generate

def req(hotel_id, active=False):
    return TripRequest(
        hotel_id=hotel_id,start_date=date(2026,9,10),nights=3,
        pace="active" if active else "relaxed",interest_active=active,
        weather_mode="normal"
    )

def test_elysium_no_pissouri():
    out=generate(req("PFO-H001"))
    assert len(out.days)==4
    assert all(d.activity.cluster_id!="C13" for d in out.days)
    ids=[d.activity.entity_id for d in out.days]
    assert len(ids)==len(set(ids))
    assert out.status=="FALLBACK_READY"
    assert out.provider_state.routing=="NOT_CONNECTED"

def test_aphrodite_hills_can_use_pissouri():
    out=generate(req("PFO-H010"))
    assert any(d.activity.cluster_id=="C13" for d in out.days)

def test_aphrodite_hills_active_surfaces_horse():
    out=generate(req("PFO-H010",True))
    assert any("Riding" in d.activity.title or "Horse" in d.activity.title for d in out.days)

def test_paradisos_active_surfaces_local_horse():
    out=generate(req("PFO-H019",True))
    assert any("Maria" in d.activity.title or "Horse" in d.activity.title for d in out.days)

def test_anassa_has_no_pissouri():
    out=generate(req("PFO-H009"))
    assert all(d.activity.cluster_id!="C13" for d in out.days)
