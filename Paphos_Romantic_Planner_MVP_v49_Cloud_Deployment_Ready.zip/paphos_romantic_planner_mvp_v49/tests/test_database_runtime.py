from app.db import connect

def test_foreign_keys_enabled():
    with connect() as c:
        assert c.execute('PRAGMA foreign_keys').fetchone()[0] == 1

def test_no_orphan_activity_clusters():
    with connect() as c:
        n=c.execute('''SELECT count(*) FROM activity a LEFT JOIN cluster c ON c.cluster_id=a.cluster_id WHERE c.cluster_id IS NULL''').fetchone()[0]
        assert n==0

def test_no_orphan_mappings():
    with connect() as c:
        n=c.execute('''SELECT count(*) FROM hotel_activity_mapping m LEFT JOIN hotel h ON h.hotel_id=m.hotel_id LEFT JOIN activity a ON a.activity_id=m.activity_id WHERE h.hotel_id IS NULL OR a.activity_id IS NULL''').fetchone()[0]
        assert n==0
