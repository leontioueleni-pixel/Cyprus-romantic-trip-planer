from app.repository import clusters, hotels, activities, restaurants, hotel_activity, hotel_restaurant

def test_seed_counts():
    assert len(clusters())==13
    assert len(hotels())==32
    assert len(activities())==166
    assert len(restaurants())==27
    assert len(hotel_activity())==3017
    assert len(hotel_restaurant())==507

def test_c13_is_limassol():
    c=clusters()['C13']
    assert c['district']=='Limassol'
    assert c['cross_district']==1
