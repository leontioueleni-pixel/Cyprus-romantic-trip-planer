from datetime import date
from app.schemas import TripRequest
from app.generator import generate

def test_day1_timeline_has_travel_activity_dinner_return():
    out=generate(TripRequest(hotel_id="PFO-H010",start_date=date(2026,9,10),nights=3,pace="active",interest_active=True,weather_mode="normal"))
    d=out.days[0]
    kinds=[x.kind for x in d.timeline]
    assert "travel" in kinds
    assert "activity" in kinds
    assert "meal" in kinds
    assert kinds[-1]=="hotel"
    assert d.timeline_qa is not None

def test_no_timeline_overlaps_in_reference_case():
    out=generate(TripRequest(hotel_id="PFO-H010",start_date=date(2026,9,10),nights=3,pace="active",interest_active=True,weather_mode="normal"))
    assert all(d.timeline_qa.overlap_count==0 for d in out.days)

def test_timeline_exposes_planning_travel():
    out=generate(TripRequest(hotel_id="PFO-H001",start_date=date(2026,9,10),nights=3,weather_mode="rainy"))
    assert all(d.timeline_qa.total_travel_minutes > 0 for d in out.days)

def test_daily_load_is_classified():
    out=generate(TripRequest(hotel_id="PFO-H001",start_date=date(2026,9,10),nights=3,weather_mode="normal"))
    assert all(d.timeline_qa.load in {"LIGHT","BALANCED","BUSY","OVERLOADED"} for d in out.days)


def test_full_days_can_include_secondary_stop_without_overlap():
    out=generate(TripRequest(hotel_id="PFO-H010",start_date=date(2026,9,10),nights=3,pace="balanced",weather_mode="normal"))
    full_days=out.days[1:]
    assert any(d.secondary_activity is not None for d in full_days)
    assert all(d.timeline_qa.overlap_count==0 for d in out.days)

def test_arrival_day_has_no_secondary_activity():
    out=generate(TripRequest(hotel_id="PFO-H010",start_date=date(2026,9,10),nights=3,pace="active",interest_active=True,weather_mode="normal"))
    assert out.days[0].secondary_activity is None


def test_selected_secondary_is_present_in_timeline():
    out=generate(TripRequest(hotel_id="PFO-H010",start_date=date(2026,9,10),nights=3,pace="balanced",weather_mode="normal"))
    for d in out.days:
        if d.secondary_activity:
            ids=[x.entity_id for x in d.timeline if x.entity_id]
            assert d.secondary_activity.entity_id in ids
