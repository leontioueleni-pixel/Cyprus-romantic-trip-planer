import os
from pathlib import Path
from fastapi.testclient import TestClient
from app.main import app

ROOT=Path(__file__).resolve().parents[1]
client=TestClient(app)

def test_cloud_deployment_files_exist():
    assert (ROOT/"Dockerfile").exists()
    assert (ROOT/"render.yaml").exists()
    assert (ROOT/"railway.json").exists()
    assert (ROOT/"scripts/start_cloud.sh").exists()

def test_docker_binds_via_cloud_start_script():
    text=(ROOT/"scripts/start_cloud.sh").read_text(encoding="utf-8")
    assert "--host 0.0.0.0" in text
    assert '${PORT:-8000}' in text

def test_public_base_url_network_mode(monkeypatch):
    monkeypatch.setenv("PUBLIC_BASE_URL","https://planner.example")
    r=client.get("/api/v1/meta/network")
    assert r.status_code==200
    data=r.json()
    assert data["mode"]=="public_cloud"
    assert data["mobile_url"]=="https://planner.example"
