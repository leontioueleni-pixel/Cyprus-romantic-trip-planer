@echo off
setlocal
cd /d "%~dp0"
title Cyprus Romantic Trip Planner - Android / Mobile Access

where python >nul 2>nul
if errorlevel 1 (
  echo.
  echo Python was not found.
  echo Install Python 3.11 or newer from python.org and select "Add Python to PATH".
  echo Then run this file again.
  echo.
  pause
  exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
  echo Creating local Python environment...
  python -m venv .venv
)

call ".venv\Scripts\activate.bat"
echo Installing / checking required packages...
python -m pip install -q -r requirements.txt

set "SQLITE_DB_PATH=%CD%\data\planner_dev.sqlite3"
if not exist "%SQLITE_DB_PATH%" (
  echo Creating the local planner database...
  python scripts\init_sqlite.py
)

for /f "tokens=2 delims=:" %%a in ('ipconfig ^| findstr /R /C:"IPv4 Address" /C:"IPv4"') do (
  set "LANIP=%%a"
  goto :foundip
)
:foundip
set "LANIP=%LANIP: =%"

echo.
echo ============================================================
echo  CYPRUS ROMANTIC TRIP PLANNER - MOBILE ACCESS
echo ============================================================
echo.
echo 1. Keep this Windows PC and your Android phone on the SAME Wi-Fi.
echo 2. On Android, open Chrome.
echo 3. Try this address:
echo.
echo       http://%LANIP%:8000
echo.
echo If Windows Firewall asks, allow access on PRIVATE networks.
echo Keep this window open while using the app on your phone.
echo Press Ctrl+C here when finished.
echo.
start "" http://127.0.0.1:8000/
python -m uvicorn app.main:app --host 0.0.0.0 --port 8000
pause
