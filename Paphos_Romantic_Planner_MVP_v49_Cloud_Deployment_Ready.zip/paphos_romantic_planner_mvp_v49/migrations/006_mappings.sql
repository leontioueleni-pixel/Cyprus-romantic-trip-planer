CREATE TABLE IF NOT EXISTS hotel_activity_mapping (
  mapping_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  hotel_id varchar(16) NOT NULL REFERENCES hotel(hotel_id),
  activity_id varchar(16) NOT NULL REFERENCES activity(activity_id),
  content_version varchar(40) NOT NULL REFERENCES content_release(content_version),
  travel_band text NOT NULL,
  recommended_day1 text NOT NULL,
  weather_fit text,
  romantic_score numeric(4,1),
  data_status varchar(24),
  UNIQUE(hotel_id,activity_id,content_version)
);
CREATE TABLE IF NOT EXISTS hotel_restaurant_mapping (
  mapping_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  hotel_id varchar(16) NOT NULL REFERENCES hotel(hotel_id),
  restaurant_id varchar(16) NOT NULL REFERENCES restaurant(restaurant_id),
  content_version varchar(40) NOT NULL REFERENCES content_release(content_version),
  travel_band text NOT NULL,
  meal_type text,
  romantic_score numeric(4,1),
  data_status varchar(24),
  UNIQUE(hotel_id,restaurant_id,content_version)
);
