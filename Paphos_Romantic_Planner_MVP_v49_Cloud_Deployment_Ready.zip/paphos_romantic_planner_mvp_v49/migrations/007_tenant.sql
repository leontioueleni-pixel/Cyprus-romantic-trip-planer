CREATE TABLE IF NOT EXISTS tenant (
  tenant_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  plan text NOT NULL DEFAULT 'public',
  status text NOT NULL DEFAULT 'active',
  config jsonb NOT NULL DEFAULT '{}'::jsonb
);
CREATE TABLE IF NOT EXISTS tenant_entitlement (
  entitlement_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenant(tenant_id) ON DELETE CASCADE,
  feature text NOT NULL,
  limit_value integer,
  active_from date,
  active_to date
);
CREATE TABLE IF NOT EXISTS tenant_content_rule (
  rule_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenant(tenant_id) ON DELETE CASCADE,
  rule_type text NOT NULL,
  rule_value jsonb NOT NULL
);
INSERT INTO tenant(name,plan,status) SELECT 'Public','public','active'
WHERE NOT EXISTS (SELECT 1 FROM tenant WHERE name='Public');
