CREATE TABLE IF NOT EXISTS hotel (
  hotel_id varchar(16) PRIMARY KEY,
  name text NOT NULL,
  cluster_id varchar(8) NOT NULL REFERENCES cluster(cluster_id),
  status varchar(24) NOT NULL,
  romantic_score numeric(4,1),
  cleanliness_score numeric(4,1),
  area text,
  payload jsonb NOT NULL DEFAULT '{}'::jsonb,
  CONSTRAINT ck_hotel_romantic CHECK (romantic_score IS NULL OR romantic_score BETWEEN 0 AND 10)
);
CREATE TABLE IF NOT EXISTS activity (
  activity_id varchar(16) PRIMARY KEY,
  name text NOT NULL,
  cluster_id varchar(8) NOT NULL REFERENCES cluster(cluster_id),
  category text NOT NULL,
  subcategory text,
  data_status varchar(24) NOT NULL,
  romantic_score numeric(4,1),
  authentic_score numeric(4,1),
  duration_min integer,
  area text,
  payload jsonb NOT NULL DEFAULT '{}'::jsonb,
  CONSTRAINT ck_activity_status CHECK (data_status IN ('Verified','Needs Recheck','Draft','Inactive')),
  CONSTRAINT ck_activity_scores CHECK (
    (romantic_score IS NULL OR romantic_score BETWEEN 0 AND 10)
    AND (authentic_score IS NULL OR authentic_score BETWEEN 0 AND 10)
  )
);
CREATE TABLE IF NOT EXISTS restaurant (
  restaurant_id varchar(16) PRIMARY KEY,
  name text NOT NULL,
  cluster_id varchar(8) NOT NULL REFERENCES cluster(cluster_id),
  data_status varchar(24) NOT NULL,
  area text,
  meal_type text,
  romantic_score numeric(4,1),
  authentic_score numeric(4,1),
  payload jsonb NOT NULL DEFAULT '{}'::jsonb,
  CONSTRAINT ck_restaurant_status CHECK (data_status IN ('Verified','Needs Recheck','Draft','Inactive'))
);
