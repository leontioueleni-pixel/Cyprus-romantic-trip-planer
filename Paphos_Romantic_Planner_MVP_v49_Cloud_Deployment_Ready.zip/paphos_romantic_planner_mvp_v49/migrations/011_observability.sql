CREATE TABLE IF NOT EXISTS generation_event (
  event_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  trip_version_id uuid REFERENCES trip_version(trip_version_id) ON DELETE SET NULL,
  stage text NOT NULL,
  status text NOT NULL,
  latency_ms integer,
  error_class text,
  payload jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
