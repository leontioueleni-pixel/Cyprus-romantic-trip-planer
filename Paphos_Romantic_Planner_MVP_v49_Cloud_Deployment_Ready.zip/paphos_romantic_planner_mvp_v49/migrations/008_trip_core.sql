CREATE TABLE IF NOT EXISTS trip_request (
  trip_request_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES tenant(tenant_id),
  hotel_id varchar(16) NOT NULL REFERENCES hotel(hotel_id),
  start_date date NOT NULL,
  nights smallint NOT NULL CHECK (nights BETWEEN 1 AND 14),
  max_drive_min smallint NOT NULL DEFAULT 20 CHECK (max_drive_min BETWEEN 5 AND 90),
  input jsonb NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS trip_version (
  trip_version_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  trip_request_id uuid NOT NULL REFERENCES trip_request(trip_request_id),
  content_version varchar(40) NOT NULL REFERENCES content_release(content_version),
  rules_version varchar(40) NOT NULL REFERENCES rules_release(rules_version),
  status varchar(24) NOT NULL,
  request_snapshot jsonb NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
