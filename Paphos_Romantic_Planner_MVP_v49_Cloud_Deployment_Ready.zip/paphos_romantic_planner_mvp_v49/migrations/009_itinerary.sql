CREATE TABLE IF NOT EXISTS itinerary_day (
  day_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  trip_version_id uuid NOT NULL REFERENCES trip_version(trip_version_id) ON DELETE CASCADE,
  day_number smallint NOT NULL,
  trip_date date NOT NULL,
  theme text,
  UNIQUE(trip_version_id,day_number)
);
CREATE TABLE IF NOT EXISTS itinerary_stop (
  stop_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  day_id uuid NOT NULL REFERENCES itinerary_day(day_id) ON DELETE CASCADE,
  stop_order smallint NOT NULL,
  entity_type varchar(16) NOT NULL,
  entity_id varchar(32),
  start_time time,
  end_time time,
  status varchar(24) NOT NULL,
  payload jsonb NOT NULL DEFAULT '{}'::jsonb,
  UNIQUE(day_id,stop_order)
);
CREATE TABLE IF NOT EXISTS booking_action (
  booking_action_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  trip_version_id uuid NOT NULL REFERENCES trip_version(trip_version_id) ON DELETE CASCADE,
  entity_id varchar(32) NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  payload jsonb NOT NULL DEFAULT '{}'::jsonb
);
