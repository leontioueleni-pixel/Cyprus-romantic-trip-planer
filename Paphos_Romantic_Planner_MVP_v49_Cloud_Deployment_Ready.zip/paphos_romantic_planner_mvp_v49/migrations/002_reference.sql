CREATE TABLE IF NOT EXISTS content_release (
  content_version varchar(40) PRIMARY KEY,
  published_at timestamptz NOT NULL DEFAULT now(),
  notes text
);
CREATE TABLE IF NOT EXISTS rules_release (
  rules_version varchar(40) PRIMARY KEY,
  published_at timestamptz NOT NULL DEFAULT now(),
  config jsonb NOT NULL DEFAULT '{}'::jsonb,
  notes text
);
CREATE TABLE IF NOT EXISTS cluster (
  cluster_id varchar(8) PRIMARY KEY,
  name text NOT NULL,
  district text NOT NULL,
  cross_district boolean NOT NULL DEFAULT false,
  content_version varchar(40) NOT NULL REFERENCES content_release(content_version),
  main_areas text,
  profile text,
  notes text,
  CONSTRAINT ck_c13_district CHECK (
    cluster_id <> 'C13' OR (district='Limassol' AND cross_district=true)
  )
);
