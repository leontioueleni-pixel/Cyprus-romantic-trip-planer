CREATE TABLE IF NOT EXISTS content_source (
  source_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  url text NOT NULL,
  source_type text,
  authority_level smallint,
  last_checked timestamptz,
  UNIQUE(url)
);
CREATE TABLE IF NOT EXISTS content_fact (
  fact_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  entity_type text NOT NULL,
  entity_id text NOT NULL,
  field_name text NOT NULL,
  fact_value jsonb NOT NULL,
  source_id uuid REFERENCES content_source(source_id),
  status text NOT NULL DEFAULT 'Verified',
  valid_from date,
  valid_to date,
  created_at timestamptz NOT NULL DEFAULT now()
);
