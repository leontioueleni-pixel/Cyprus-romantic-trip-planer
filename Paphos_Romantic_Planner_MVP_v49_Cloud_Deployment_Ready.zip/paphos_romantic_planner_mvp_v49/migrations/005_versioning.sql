INSERT INTO content_release(content_version,notes)
VALUES ('content_2026_08_27','Initial Paphos production content seed')
ON CONFLICT DO NOTHING;
INSERT INTO rules_release(rules_version,config,notes)
VALUES ('rules_1_0','{}'::jsonb,'Initial itinerary rules release')
ON CONFLICT DO NOTHING;
