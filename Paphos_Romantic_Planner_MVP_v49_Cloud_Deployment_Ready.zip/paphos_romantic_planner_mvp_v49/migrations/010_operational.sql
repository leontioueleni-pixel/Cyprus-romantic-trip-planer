CREATE TABLE IF NOT EXISTS route_leg (
  route_leg_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  trip_version_id uuid NOT NULL REFERENCES trip_version(trip_version_id) ON DELETE CASCADE,
  origin_stop_id uuid REFERENCES itinerary_stop(stop_id),
  destination_stop_id uuid REFERENCES itinerary_stop(stop_id),
  duration_min numeric(8,2),
  distance_km numeric(8,3),
  status varchar(16) NOT NULL CHECK (status IN ('LIVE','STALE','FALLBACK','INVALID','NOT_CONNECTED')),
  retrieved_at timestamptz,
  provider text,
  payload jsonb,
  CONSTRAINT ck_route_live CHECK (status <> 'LIVE' OR (duration_min > 0 AND distance_km >= 0 AND retrieved_at IS NOT NULL))
);
CREATE TABLE IF NOT EXISTS weather_day (
  weather_day_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  trip_version_id uuid NOT NULL REFERENCES trip_version(trip_version_id) ON DELETE CASCADE,
  trip_date date NOT NULL,
  temp_max_c numeric(5,2),
  precip_prob_max_pct numeric(5,2),
  precip_sum_mm numeric(8,2),
  wind_gust_max_kmh numeric(8,2),
  weather_code integer,
  derived_mode varchar(16),
  sea_caution boolean,
  status varchar(16) NOT NULL CHECK (status IN ('LIVE','STALE','FALLBACK','INVALID','NOT_CONNECTED')),
  retrieved_at timestamptz,
  UNIQUE(trip_version_id,trip_date),
  CONSTRAINT ck_weather_live CHECK (
    status <> 'LIVE' OR (
      temp_max_c BETWEEN -20 AND 60
      AND precip_prob_max_pct BETWEEN 0 AND 100
      AND precip_sum_mm >= 0
      AND wind_gust_max_kmh >= 0
      AND retrieved_at IS NOT NULL
    )
  )
);
