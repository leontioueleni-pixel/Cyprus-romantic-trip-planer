CREATE INDEX IF NOT EXISTS idx_hotel_cluster_status ON hotel(cluster_id,status);
CREATE INDEX IF NOT EXISTS idx_activity_cluster_status ON activity(cluster_id,data_status);
CREATE INDEX IF NOT EXISTS idx_activity_category_status ON activity(category,data_status);
CREATE INDEX IF NOT EXISTS idx_rest_cluster_status ON restaurant(cluster_id,data_status);
CREATE INDEX IF NOT EXISTS idx_trip_version_latest ON trip_version(trip_request_id,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_route_trip_status ON route_leg(trip_version_id,status);
-- QA is completed by scripts/qa_seed.py and pytest.
