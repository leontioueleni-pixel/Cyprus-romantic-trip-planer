UPDATE rules_release SET config = '{
  "R001":{"heatwave_temp_c":35,"avoid_outdoor_from":"12:00","avoid_outdoor_to":"16:30"},
  "R002":{"rain_prefers_indoor":true},
  "R003":{"arrival_day_preferred_drive_min":20},
  "R004":{"non_verified_not_auto_primary":true},
  "XD001":{"C13_district":"Limassol"},
  "XD002":{"C02_to_C13_max_normal_drive_min":30},
  "XD003":{"C02_to_C13_arrival_preferred_drive_min":20}
}'::jsonb WHERE rules_version='rules_1_0';
