@echo off
setlocal
cd /d "%~dp0"
title Cyprus Romantic Trip Planner - Paphos MVP

where python >nul 2>nul
if errorlevel 1 (
  echo.
  echo Python was not found.
  echo Install Python 3.11 or newer from python.org and select "Add Python to PATH".
  echo Then run this file again.
  echo.
  pause
  exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
  echo Creating local Python environment...
  python -m venv .venv
)

call ".venv\Scripts\activate.bat"
echo Installing / checking required packages...
python -m pip install -q -r requirements.txt

set "SQLITE_DB_PATH=%CD%\data\planner_dev.sqlite3"
if not exist "%SQLITE_DB_PATH%" (
  echo Creating the local planner database...
  python scripts\init_sqlite.py
)

echo.
echo Starting Cyprus Romantic Trip Planner...
echo The browser will open automatically.
echo To stop the planner, return to this window and press Ctrl+C.
echo.
start "" cmd /c "timeout /t 3 /nobreak >nul & start http://127.0.0.1:8000/"
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
pause
