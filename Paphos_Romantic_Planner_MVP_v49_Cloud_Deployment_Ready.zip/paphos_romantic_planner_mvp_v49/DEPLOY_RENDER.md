# Deploy on Render — recommended first public test

This repository includes `render.yaml` and a `Dockerfile`.

## Before you begin
Create a GitHub repository and upload the contents of this project folder.

## Render steps
1. Sign in to Render.
2. Create a new **Web Service** from the GitHub repository.
3. Use the included Dockerfile / Blueprint configuration.
4. Set these environment variables:
   - `APP_ENV=production`
   - `ENABLE_LIVE_PROVIDERS=false`
   - `CONTENT_VERSION=content_2026_08_27`
   - `RULES_VERSION=rules_1_0`
5. After the first deployment, copy the public `https://...onrender.com` URL.
6. Add:
   - `PUBLIC_BASE_URL=https://YOUR-SERVICE.onrender.com`
7. Redeploy.

Your Android phone can then open the public HTTPS URL using mobile data or any Wi-Fi.

## Health check
Open:
`https://YOUR-SERVICE.onrender.com/api/v1/health`

Expected:
- service = ok
- routing_provider = not_connected
- weather_provider = not_connected

## Important MVP storage note
The current cloud image rebuilds the curated SQLite database from seed files when the container starts.
That is acceptable for the current read-mostly itinerary generator.
Before adding saved customer trips, accounts, billing, bookings or admin edits, move transactional persistence to managed PostgreSQL.
